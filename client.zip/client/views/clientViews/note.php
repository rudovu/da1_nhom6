<div class="gioi-thieu">
<div class="form-row ">
            <div class="form-group col-md-1"></div>
            <div class="form-group col-md-4 w">
                <img style="width: 440px; height:400px" src="./assets/images/1.jpg" alt="">
            </div>
            <div class="form-group col-md-6">
                <ul>
                <li class="title"><a href="">Ghế tựa</a></li>
                    <li><i>Ghế tựa bằng da thuộc được đánh giá là nguyên vật liệu có độ bền cao, dẻo dai và lâu bền với thời gian. Nó là thành phẩm được tạo nên từ quy trình thuộc da với nguyên liệu chính là da động vật như trâu, bò, nai, cá sấu, dê, cừu… Trong số đó, da bò được sản xuất với số lượng lớn và phong phú nhất.</i></li>
                </ul>
            </div>
        </div>
</div>
<div class="gioi-thieu">
<div class="form-row ">
            <div class="form-group col-md-1"></div>
            <div class="form-group col-md-4 ">
                <img style="width: 440px; height:400px" src="./assets/images/2.jpg" alt="">
            </div>
            <div class="form-group col-md-6">
                <ul>
                <li class="title"><a href="">Bộ ghế sofa</a></li>
                    <li><i>Vải nỉ là chất liệu mềm nên được sử dụng rộng rãi để may các đồ nội thất như rèm cửa, thảm trải sàn... Lớp này không chỉ bảo vệ đồ nội thất theo một cách nào đó mà còn giảm độ cứng khi sử dụng áo bọc ghế, giúp sờ vào thoải mái và êm ái hơn, không gây đau nhức lưng do ngồi lâu.</i></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="product-item">
        <div class="form-row">
            <div class="form-group col-md-1"></div>
            <div class="form-group col-md-4">
                <a href=""><img style="width: 440px; height:400px" src="./assets/images/7.jpg" alt=""></a>
            </div>
            <div class="form-group col-md-6">
                <ul>
                <li class="title"><a href="">Bộ Sofa nỉ</a></li>
                    <li><i>Đồ nỉ nội thất là một phạm trù để sử dụng để kể về những sản phẩm đồ dùng được sử dụng phục vụ cho cuộc sống gia đình với chất liệu bằng gỗ. Đây là các sản phẩm có lịch sử xuất hiện lâu đời và phát triển qua từng giai đoạn với từng đặc trưng khác nhau, mang đến những trải nghiệm sử dụng mới lạ cho con người.</i></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="product-item">
        <div class="form-row">
            <div class="form-group col-md-1"></div>
            <div class="form-group col-md-4">
                <a href=""><img style="width: 440px; height:400px" src="./assets/images/4.jpg" alt=""></a>
            </div>
            <div class="form-group col-md-6">
                <ul>
                <li class="title"><a href="">Bộ Sofa da</a></li>
                    <li><i>Đồ nội thất bằng da thuộc được đánh giá là nguyên vật liệu có độ bền cao, dẻo dai và lâu bền với thời gian. Nó là thành phẩm được tạo nên từ quy trình thuộc da với nguyên liệu chính là da động vật như trâu, bò, nai, cá sấu, dê, cừu… Trong số đó, da bò được sản xuất với số lượng lớn và phong phú nhất.</i></li>
                </ul>
            </div>
        </div>
    </div>